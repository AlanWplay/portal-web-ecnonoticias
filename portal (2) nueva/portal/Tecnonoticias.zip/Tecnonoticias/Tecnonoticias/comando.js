// Crear el contenedor div
const div = document.createElement('div');
div.className = 'boton';

// Crear el formulario
const form = document.createElement('form');
form.action = '/buscar';
form.method = 'get';

// Crear el input de búsqueda
const input = document.createElement('input');
input.type = 'text';
input.name = 'q';
input.placeholder = 'Buscar...';

// Crear el botón
const button = document.createElement('button');
button.type = 'submit';
button.textContent = 'Buscar';

// Ensamblar todo
form.appendChild(input);
form.appendChild(button);
div.appendChild(form);

// Agregar al documento
document.body.appendChild(div);


/* Busca*/

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const searchForm = document.getElementById('searchForm');
            const searchInput = document.querySelector('input[name="q"]');
            const resultsInfo = document.getElementById('resultsInfo');
            const contentSections = document.querySelectorAll('.content-section p');
            
            // Función para realizar la búsqueda
            function performSearch(event) {
                event.preventDefault(); // Prevenir envío del formulario
                
                const searchTerm = searchInput.value.trim();
                
                if (searchTerm === '') {
                    resultsInfo.textContent = 'Por favor, ingresa un término de búsqueda.';
                    removeHighlights();
                    return;
                }
                
                let foundCount = 0;
                removeHighlights();
                
                // Buscar en cada párrafo de contenido
                contentSections.forEach(paragraph => {
                    const text = paragraph.textContent;
                    const regex = new RegExp(`(${searchTerm})`, 'gi');
                    
                    if (regex.test(text)) {
                        foundCount++;
                        paragraph.innerHTML = text.replace(regex, '<span class="highlight">$1</span>');
                    }
                });
                
                // Mostrar resultados
                if (foundCount > 0) {
                    resultsInfo.textContent = `Se encontraron ${foundCount} resultados para "${searchTerm}".`;
                    resultsInfo.style.color = '#27ae60';
                    
                    // Desplazarse al primer resultado
                    const firstHighlight = document.querySelector('.highlight');
                    if (firstHighlight) {
                        firstHighlight.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                } else {
                    resultsInfo.textContent = `No se encontraron resultados para "${searchTerm}".`;
                    resultsInfo.style.color = '#e74c3c';
                }
            }
            
            // Función para eliminar resaltados anteriores
            function removeHighlights() {
                const highlights = document.querySelectorAll('.highlight');
                highlights.forEach(highlight => {
                    const parent = highlight.parentNode;
                    parent.replaceChild(document.createTextNode(highlight.textContent), highlight);
                    parent.normalize();
                });
            }
            
            // Agregar evento al formulario
            searchForm.addEventListener('submit', performSearch);
            
            // Agregar evento para búsqueda en tiempo real (opcional)
            searchInput.addEventListener('input', function() {
                if (this.value === '') {
                    removeHighlights();
                    resultsInfo.textContent = '';
                }
            });
        });
    </script>
